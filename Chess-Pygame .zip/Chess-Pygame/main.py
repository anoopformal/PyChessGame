# main.py (fixed - handles gameover sound without corrupting move_history)
import pygame
import sys
import random
import time
from collections import deque

pygame.init()

# ----- Configuration -----
WIDTH, HEIGHT = 1000, 800           # extra width for sidebar
BOARD_SIZE = 800
SQUARE_SIZE = BOARD_SIZE // 8
SIDEBAR_WIDTH = WIDTH - BOARD_SIZE

FPS = 60

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BROWN = (139, 69, 19)
YELLOW = (255, 255, 0)
GREEN = (34, 139, 34)
LIGHT_BLUE = (173, 216, 230)
GRAY = (220, 220, 220)
RED = (220, 20, 60)

# ----- Globals set at runtime -----
HUMAN_COLOR = 'white'   # will be assigned by menu for HVH or HVAI
AI_COLOR = 'black'      # when AI enabled
ai_enabled = False

# For preventing repeated gameover sound
gameover_sound_played = False

# ----- Screen -----
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Chess: Human vs Human / Human vs AI")
clock = pygame.time.Clock()
font = pygame.font.SysFont('arial', 18)
large_font = pygame.font.SysFont('arial', 28)

# ----- Sound helpers (safe) -----
class DummySound:
    def play(self):
        pass

def load_sound_safe(path):
    try:
        return pygame.mixer.Sound(path)
    except Exception:
        return DummySound()

move_sound = load_sound_safe("assets/sounds/move.wav")
capture_sound = load_sound_safe("assets/sounds/capture.wav")
check_sound = load_sound_safe("assets/sounds/check.wav")
gameover_sound = load_sound_safe("assets/sounds/gameover.wav")

# ----- Chess piece class -----
def load_image_safe(path):
    """
    Load and scale an image. If loading fails, create a placeholder surface with piece initial.
    """
    try:
        img = pygame.image.load(path).convert_alpha()
        img = pygame.transform.smoothscale(img, (SQUARE_SIZE, SQUARE_SIZE))
        return img
    except Exception:
        # create placeholder surface (transparent)
        surf = pygame.Surface((SQUARE_SIZE, SQUARE_SIZE), pygame.SRCALPHA)
        surf.fill((0, 0, 0, 0))
        return surf

class ChessPiece:
    def __init__(self, color, type_, image_path=None):
        self.color = color
        self.type = type_
        if image_path:
            self.image = load_image_safe(image_path)
        else:
            self.image = None
        self.has_moved = False

    def clone_light(self):
        """Return lightweight dict representation (no Surface)"""
        return {'color': self.color, 'type': self.type, 'has_moved': bool(self.has_moved)}

# ----- Board state -----
board = [[None for _ in range(8)] for _ in range(8)]
current_player = 'white'
selected_piece = None
selected_pos = None
valid_moves_for_selected = []
last_move = None  # ((r_from,c_from),(r_to,c_to))
move_history = []  # stack of (from_pos, to_pos, captured_piece_light, moved_piece_prev_has_moved, promotion_type_or_None)
position_history = deque(maxlen=1000)

# ----- Initialize board -----
def init_board():
    global board, current_player, selected_piece, selected_pos, valid_moves_for_selected, last_move, move_history, gameover_sound_played
    board = [[None for _ in range(8)] for _ in range(8)]
    # Pawns
    for col in range(8):
        board[1][col] = ChessPiece('black', 'pawn', 'images/black_pawn.png')
        board[6][col] = ChessPiece('white', 'pawn', 'images/white_pawn.png')
    # Rooks
    board[0][0] = board[0][7] = ChessPiece('black', 'rook', 'images/black_rook.png')
    board[7][0] = board[7][7] = ChessPiece('white', 'rook', 'images/white_rook.png')
    # Knights
    board[0][1] = board[0][6] = ChessPiece('black', 'knight', 'images/black_knight.png')
    board[7][1] = board[7][6] = ChessPiece('white', 'knight', 'images/white_knight.png')
    # Bishops
    board[0][2] = board[0][5] = ChessPiece('black', 'bishop', 'images/black_bishop.png')
    board[7][2] = board[7][5] = ChessPiece('white', 'bishop', 'images/white_bishop.png')
    # Queens
    board[0][3] = ChessPiece('black', 'queen', 'images/black_queen.png')
    board[7][3] = ChessPiece('white', 'queen', 'images/white_queen.png')
    # Kings
    board[0][4] = ChessPiece('black', 'king', 'images/black_king.png')
    board[7][4] = ChessPiece('white', 'king', 'images/white_king.png')

    current_player = 'white'
    selected_piece = None
    selected_pos = None
    valid_moves_for_selected = []
    last_move = None
    move_history = []
    position_history.clear()
    gameover_sound_played = False
    save_position()

# ----- Drawing helpers -----
def draw_board():
    # Board squares
    for row in range(8):
        for col in range(8):
            color = WHITE if (row + col) % 2 == 0 else BROWN
            rect = pygame.Rect(col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE)
            pygame.draw.rect(screen, color, rect)

    # Highlight last move
    if last_move:
        (r1, c1), (r2, c2) = last_move
        s = pygame.Surface((SQUARE_SIZE, SQUARE_SIZE), pygame.SRCALPHA)
        s.fill((255, 255, 0, 80))
        screen.blit(s, (c1 * SQUARE_SIZE, r1 * SQUARE_SIZE))
        screen.blit(s, (c2 * SQUARE_SIZE, r2 * SQUARE_SIZE))

    # Highlight selected square
    if selected_pos:
        r, c = selected_pos
        pygame.draw.rect(screen, YELLOW, (c * SQUARE_SIZE, r * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE), 3)

    # Draw valid move markers
    for mv in valid_moves_for_selected:
        r, c = mv
        center = (c * SQUARE_SIZE + SQUARE_SIZE // 2, r * SQUARE_SIZE + SQUARE_SIZE // 2)
        piece_on_target = board[r][c]
        if piece_on_target is None:
            pygame.draw.circle(screen, LIGHT_BLUE, center, SQUARE_SIZE // 8)
        else:
            pygame.draw.circle(screen, RED, center, SQUARE_SIZE // 3, 3)

def draw_pieces():
    for r in range(8):
        for c in range(8):
            piece = board[r][c]
            if piece and piece.image:
                screen.blit(piece.image, (c * SQUARE_SIZE, r * SQUARE_SIZE))
            elif piece:
                # fallback draw: letter on square
                label = piece.type[0].upper()
                color = BLACK if piece.color == 'white' else WHITE
                txt = font.render(label, True, color)
                tx = c * SQUARE_SIZE + SQUARE_SIZE // 2 - txt.get_width() // 2
                ty = r * SQUARE_SIZE + SQUARE_SIZE // 2 - txt.get_height() // 2
                screen.blit(txt, (tx, ty))

def draw_sidebar():
    sidebar_rect = pygame.Rect(BOARD_SIZE, 0, SIDEBAR_WIDTH, HEIGHT)
    pygame.draw.rect(screen, GRAY, sidebar_rect)

    title = large_font.render("Controls & Info", True, BLACK)
    screen.blit(title, (BOARD_SIZE + 10, 10))

    turn_text = f"Turn: {current_player.capitalize()}"
    screen.blit(font.render(turn_text, True, BLACK), (BOARD_SIZE + 10, 60))

    status = ""
    if is_check(current_player):
        status = "Check!"
    if is_game_over():
        if is_check(current_player):
            status = f"Checkmate! {('Black' if current_player=='white' else 'White')} wins"
        else:
            status = "Stalemate!"
    status_surf = font.render(status, True, RED if "Check" in status else BLACK)
    screen.blit(status_surf, (BOARD_SIZE + 10, 90))

    undo_btn = pygame.Rect(BOARD_SIZE + 10, 130, SIDEBAR_WIDTH - 20, 36)
    restart_btn = pygame.Rect(BOARD_SIZE + 10, 180, SIDEBAR_WIDTH - 20, 36)
    pygame.draw.rect(screen, WHITE, undo_btn)
    pygame.draw.rect(screen, WHITE, restart_btn)
    pygame.draw.rect(screen, BLACK, undo_btn, 2)
    pygame.draw.rect(screen, BLACK, restart_btn, 2)
    screen.blit(font.render("Undo", True, BLACK), (undo_btn.x + 10, undo_btn.y + 8))
    screen.blit(font.render("Restart", True, BLACK), (restart_btn.x + 10, restart_btn.y + 8))

    mh_title = font.render("Move History (most recent first)", True, BLACK)
    screen.blit(mh_title, (BOARD_SIZE + 10, 240))
    y = 270
    for idx, move in enumerate(reversed(move_history[-18:])):
        # move is (from_pos, to_pos, captured_light, prev_has_moved, promotion)
        (r1c1, r2c2, captured_light, prev_has_moved, promotion) = move
        # r1c1 and r2c2 are tuples or possibly invalid; handle gracefully
        if not r1c1 or not r2c2:
            # skip malformed/placeholder entries if any
            continue
        (r1, c1) = r1c1
        (r2, c2) = r2c2
        notation = f"{coord_to_algeb((r1,c1))}->{coord_to_algeb((r2,c2))}"
        if captured_light:
            notation += " x"
        if promotion:
            notation += f"={promotion[0].upper()}"
        screen.blit(font.render(notation, True, BLACK), (BOARD_SIZE + 10, y))
        y += 18

    help_lines = [
        "Click a piece to see moves.",
        "Click a valid square to move.",
        f"Mode: {'Human vs AI' if ai_enabled else 'Human vs Human'}",
        f"Human: {HUMAN_COLOR.capitalize()}",
        f"AI: {AI_COLOR.capitalize() if ai_enabled else '—'}"
    ]
    y = HEIGHT - 110
    for hl in help_lines:
        screen.blit(font.render(hl, True, BLACK), (BOARD_SIZE + 10, y))
        y += 18

    return undo_btn, restart_btn

# ----- Utility functions -----
def in_bounds(r, c):
    return 0 <= r < 8 and 0 <= c < 8

def coord_to_algeb(pos):
    # Return '--' for invalid positions
    if not pos or pos[0] is None or pos[1] is None:
        return "--"
    r, c = pos
    try:
        file = chr(ord('a') + c)
        rank = str(8 - r)
        return file + rank
    except Exception:
        return "--"

def save_position():
    """
    Save a lightweight snapshot of board to avoid copying pygame Surfaces.
    Stored cell: None or dict {'type','color','has_moved'}
    """
    light = []
    for row in board:
        lr = []
        for p in row:
            lr.append(None if p is None else p.clone_light())
        light.append(lr)
    position_history.append(light)

# ----- Move generation (pseudolegal) -----
def get_valid_moves(piece, row, col):
    moves = []
    if piece is None:
        return moves
    if piece.type == 'pawn':
        direction = -1 if piece.color == 'white' else 1
        # single
        if in_bounds(row + direction, col) and board[row + direction][col] is None:
            moves.append((row + direction, col))
            # double
            start_row = 6 if piece.color == 'white' else 1
            if row == start_row and board[row + 2*direction][col] is None:
                moves.append((row + 2*direction, col))
        # captures
        for dc in (-1, 1):
            r, c = row + direction, col + dc
            if in_bounds(r, c) and board[r][c] and board[r][c].color != piece.color:
                moves.append((r, c))
    elif piece.type == 'rook':
        for dr, dc in [(1,0),(-1,0),(0,1),(0,-1)]:
            r, c = row + dr, col + dc
            while in_bounds(r, c):
                if board[r][c] is None:
                    moves.append((r, c))
                elif board[r][c].color != piece.color:
                    moves.append((r, c)); break
                else:
                    break
                r += dr; c += dc
    elif piece.type == 'knight':
        for dr, dc in [(2,1),(2,-1),(-2,1),(-2,-1),(1,2),(1,-2),(-1,2),(-1,-2)]:
            r, c = row + dr, col + dc
            if in_bounds(r, c) and (board[r][c] is None or board[r][c].color != piece.color):
                moves.append((r, c))
    elif piece.type == 'bishop':
        for dr, dc in [(1,1),(1,-1),(-1,1),(-1,-1)]:
            r, c = row + dr, col + dc
            while in_bounds(r, c):
                if board[r][c] is None:
                    moves.append((r, c))
                elif board[r][c].color != piece.color:
                    moves.append((r, c)); break
                else:
                    break
                r += dr; c += dc
    elif piece.type == 'queen':
        for dr, dc in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]:
            r, c = row + dr, col + dc
            while in_bounds(r, c):
                if board[r][c] is None:
                    moves.append((r, c))
                elif board[r][c].color != piece.color:
                    moves.append((r, c)); break
                else:
                    break
                r += dr; c += dc
    elif piece.type == 'king':
        for dr in (-1,0,1):
            for dc in (-1,0,1):
                if dr == 0 and dc == 0: continue
                r, c = row + dr, col + dc
                if in_bounds(r, c) and (board[r][c] is None or board[r][c].color != piece.color):
                    moves.append((r, c))
    return moves

# ----- Rules: check and game over -----
def find_king(color):
    for r in range(8):
        for c in range(8):
            p = board[r][c]
            if p and p.color == color and p.type == 'king':
                return (r, c)
    return None

def is_check(color):
    king_pos = find_king(color)
    if king_pos is None:
        return False
    for r in range(8):
        for c in range(8):
            p = board[r][c]
            if p and p.color != color:
                if king_pos in get_valid_moves(p, r, c):
                    return True
    return False

def is_game_over():
    # If current player has any legal move that doesn't leave king in check -> not over
    for r in range(8):
        for c in range(8):
            p = board[r][c]
            if p and p.color == current_player:
                for mv in get_valid_moves(p, r, c):
                    captured = board[mv[0]][mv[1]]
                    orig = board[r][c]
                    board[mv[0]][mv[1]] = orig
                    board[r][c] = None
                    safe = not is_check(current_player)
                    board[r][c] = orig
                    board[mv[0]][mv[1]] = captured
                    if safe:
                        return False
    return True

# ----- Move application / undo -----
def make_move(from_pos, to_pos, promotion_choice=None):
    r1, c1 = from_pos
    r2, c2 = to_pos
    moved_piece = board[r1][c1]
    captured = board[r2][c2]
    prev_has_moved = moved_piece.has_moved if moved_piece else None

    board[r2][c2] = moved_piece
    board[r1][c1] = None
    if moved_piece:
        moved_piece.has_moved = True

    promotion = None
    if moved_piece and moved_piece.type == 'pawn' and (r2 == 0 or r2 == 7):
        promote_to = promotion_choice if promotion_choice else 'queen'
        color = moved_piece.color
        board[r2][c2] = ChessPiece(color, promote_to, f'images/{color}_{promote_to}.png')
        promotion = promote_to

    global last_move
    last_move = (from_pos, to_pos)
    captured_light = None if captured is None else captured.clone_light()
    move_record = (from_pos, to_pos, captured_light, prev_has_moved, promotion)
    move_history.append(move_record)
    save_position()

    # Play sounds (move or capture)
    if captured is None:
        move_sound.play()
    else:
        capture_sound.play()

    # If the move caused a check, play check sound
    if is_check('white' if moved_piece.color == 'black' else 'black'):
        check_sound.play()

    return move_record

def undo_move():
    if not move_history:
        return
    from_pos, to_pos, captured_light, prev_has_moved, promotion = move_history.pop()
    r1, c1 = from_pos
    r2, c2 = to_pos
    moved_piece = board[r2][c2]
    if promotion and moved_piece:
        pawn_color = moved_piece.color
        board[r1][c1] = ChessPiece(pawn_color, 'pawn', f'images/{pawn_color}_pawn.png')
        board[r1][c1].has_moved = prev_has_moved
    else:
        board[r1][c1] = moved_piece
        if board[r1][c1]:
            board[r1][c1].has_moved = prev_has_moved
    # restore captured piece if any
    if captured_light:
        board[r2][c2] = ChessPiece(captured_light['color'], captured_light['type'],
                                    f"images/{captured_light['color']}_{captured_light['type']}.png")
        board[r2][c2].has_moved = captured_light['has_moved']
    else:
        board[r2][c2] = None

    global last_move, selected_piece, selected_pos, valid_moves_for_selected, current_player
    selected_piece = None
    selected_pos = None
    valid_moves_for_selected = []
    last_move = move_history[-1][0:2] if move_history else None
    # switch turn back
    current_player = 'black' if current_player == 'white' else 'white'

# ----- Legal moves that respect check -----
def legal_moves_for_piece(r, c):
    p = board[r][c]
    if not p:
        return []
    moves = []
    for mv in get_valid_moves(p, r, c):
        captured = board[mv[0]][mv[1]]
        orig = board[r][c]
        board[mv[0]][mv[1]] = orig
        board[r][c] = None
        in_check = is_check(p.color)
        board[r][c] = orig
        board[mv[0]][mv[1]] = captured
        if not in_check:
            moves.append(mv)
    return moves

def generate_all_legal_moves(color):
    all_moves = []
    for r in range(8):
        for c in range(8):
            p = board[r][c]
            if p and p.color == color:
                for mv in legal_moves_for_piece(r, c):
                    all_moves.append(((r, c), mv))
    return all_moves

# ----- Simple AI: random legal move -----
def ai_make_move_random():
    moves = generate_all_legal_moves(AI_COLOR)
    if not moves:
        return
    move = random.choice(moves)
    from_pos, to_pos = move
    make_move(from_pos, to_pos)
    global current_player
    current_player = HUMAN_COLOR

# ----- Input handling & main loop -----
def handle_click_global(mouse_pos, undo_btn, restart_btn):
    global selected_piece, selected_pos, valid_moves_for_selected, current_player
    mx, my = mouse_pos
    if mx < BOARD_SIZE and my < BOARD_SIZE:
        col = mx // SQUARE_SIZE
        row = my // SQUARE_SIZE
        clicked_piece = board[row][col]
        if selected_piece is None:
            if clicked_piece and clicked_piece.color == current_player:
                selected_piece = clicked_piece
                selected_pos = (row, col)
                valid_moves_for_selected = legal_moves_for_piece(row, col)
        else:
            if selected_pos == (row, col):
                selected_piece = None
                selected_pos = None
                valid_moves_for_selected = []
            elif (row, col) in valid_moves_for_selected and (not ai_enabled or current_player == HUMAN_COLOR):
                # make move
                make_move(selected_pos, (row, col))
                # switch turn
                current_player = 'black' if current_player == 'white' else 'white'
                selected_piece = None
                selected_pos = None
                valid_moves_for_selected = []
            else:
                if clicked_piece and clicked_piece.color == current_player:
                    selected_piece = clicked_piece
                    selected_pos = (row, col)
                    valid_moves_for_selected = legal_moves_for_piece(row, col)
                else:
                    selected_piece = None
                    selected_pos = None
                    valid_moves_for_selected = []
    else:
        if undo_btn.collidepoint(mouse_pos):
            undo_move()
        elif restart_btn.collidepoint(mouse_pos):
            init_board()

# ----- Start menu -----
def start_menu(screen):
    menu_font = pygame.font.SysFont("arial", 36)
    small = pygame.font.SysFont("arial", 24)
    clock_local = pygame.time.Clock()

    while True:
        screen.fill((30, 30, 30))
        title = menu_font.render("Chess Game", True, (240, 240, 240))
        option1 = small.render("1: Play with Human (Human vs Human)", True, (200, 200, 200))
        option2 = small.render("2: Play with Computer (Human vs AI)", True, (200, 200, 200))
        note = small.render("Press 1 or 2 to choose. Esc to quit.", True, (150, 150, 150))

        screen.blit(title, (BOARD_SIZE//2 - title.get_width()//2, 120))
        screen.blit(option1, (BOARD_SIZE//2 - option1.get_width()//2, 220))
        screen.blit(option2, (BOARD_SIZE//2 - option2.get_width()//2, 260))
        screen.blit(note, (BOARD_SIZE//2 - note.get_width()//2, 340))

        pygame.display.flip()
        clock_local.tick(30)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                elif event.key == pygame.K_1:
                    return False  # ai_enabled = False
                elif event.key == pygame.K_2:
                    return True   # ai_enabled = True

# ----- Main -----
def main():
    global current_player, ai_enabled, HUMAN_COLOR, AI_COLOR, gameover_sound_played

    # show menu and decide mode
    ai_enabled = start_menu(screen)
    # set players: human always white by default for simplicity
    HUMAN_COLOR = 'white'
    AI_COLOR = 'black'

    init_board()
    current_player = 'white'

    running = True
    while running:
        clock.tick(FPS)
        screen.fill(BLACK)
        draw_board()
        draw_pieces()
        undo_btn, restart_btn = draw_sidebar()
        pygame.display.flip()

        # If it's AI's turn and AI enabled, make random move
        if ai_enabled and current_player == AI_COLOR and not is_game_over():
            pygame.time.delay(200)
            ai_make_move_random()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break
            elif event.type == pygame.MOUSEBUTTONDOWN:
                handle_click_global(pygame.mouse.get_pos(), undo_btn, restart_btn)
            elif event.type == pygame.KEYDOWN:
                # simple keyboard shortcuts
                if event.key == pygame.K_u:
                    undo_move()
                elif event.key == pygame.K_r:
                    init_board()
                elif event.key == pygame.K_ESCAPE:
                    running = False
                    break

        # Game over detection and play gameover sound once
        if is_game_over() and not gameover_sound_played:
            gameover_sound.play()
            gameover_sound_played = True

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
