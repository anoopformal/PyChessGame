@echo off
color A
Title created By Anoop
Prompt Created By Anoop
echo Wait few second.........
pip install pygame
cd /d "%~dp0"

::cd C:\Users\here_should your directory name
python main.py
pause
exit